-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 20/09/2024 às 12:47
-- Versão do servidor: 10.4.22-MariaDB
-- Versão do PHP: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
Create database if not exists `banconote`;
use `banconote`;
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `cpf_cnpj` varchar(14) NOT NULL,
  `birthdate` datetime NOT NULL,
  `address` varchar(255) NOT NULL,
  `hood` varchar(100) NOT NULL,
  `zip_code` varchar(8) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(2) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `ie` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `customers`
--

INSERT INTO `customers` (`id`, `name`, `cpf_cnpj`, `birthdate`, `address`, `hood`, `zip_code`, `city`, `state`, `phone`, `mobile`, `ie`, `created`, `modified`) VALUES
(1, 'Fulano de Tal', '123.456.789-00', '1989-01-01 00:00:00', 'Rua da Web, 123', 'Internet', '12345678', 'Teste', 'SP', '15 55663322', '15 955663322', 123456777, '2016-05-24 00:00:00', '2016-05-24 00:00:00'),
(2, 'Ciclano de Tal', '123.456.789-00', '1989-01-01 00:00:00', 'Rua da Web, 123', 'Internet', '12345678', 'Teste', 'SP', '15 55663322', '15 955663322', 123456777, '2016-05-24 00:00:00', '2016-05-24 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tabeladados`
--

CREATE TABLE IF NOT EXISTS `tabeladados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `quadro` varchar(255) NOT NULL,
  `urgencia` int(11) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `cep` varchar(8) NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `celular` varchar(13) NOT NULL,
  `aniversario` date NOT NULL,
  `imagem` varchar(50) NOT NULL,
  `modificado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `tabeladados`
--

INSERT INTO `tabeladados` (`id`, `nome`, `quadro`, `urgencia`, `cpf`, `cep`, `sexo`, `celular`, `aniversario`,`imagem`, `modificado`) VALUES
(1, 'Pedro', 'Gripe', 2,'28932886857', '18052080', 'M', '15997126962', '2020-05-01',  'dellinsp.jpg', '2024-09-15 10:00:00'),
(2, 'Gustavo', 'Gripe', 2,'28932886857', '18052080', 'M', '15997126962', '2020-05-01',  'dellinsp.jpg', '2024-09-15 10:00:00'),
(3, 'Layza', 'Gripe', 2,'28932886857', '18052080', 'F', '15997126962', '2020-05-01',  'dellinsp.jpg', '2024-09-15 10:00:00'),
(4, 'Maria', 'Gripe', 2,'28932886857', '18052080', 'F', '15997126962', '2020-05-01',  'dellinsp.jpg', '2024-09-15 10:00:00'),
(5, 'Guilherme', 'Gripe', 2,'28932886857', '18052080', 'M', '15997126962', '2020-05-01',  'dellinsp.jpg', '2024-09-15 10:00:00');

CREATE TABLE usuarios(
    id int AUTO_INCREMENT not null PRIMARY KEY,
    nome varchar(50) not null,
    user varchar(50) not null,
    password varchar(100) not null,
    foto varchar(50)
);

-- Script para criar e cadastrar na tabela usuários (execute no banco do projeto):
INSERT INTO `usuarios`(`nome`, `user`, `password`) 
VALUES ('Zé Lele','zelele','5243897562837456982'),
('Mary Zica','mazi','786098767869'),
('Fugiru Nakombi','fugina','623485634753234');

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
