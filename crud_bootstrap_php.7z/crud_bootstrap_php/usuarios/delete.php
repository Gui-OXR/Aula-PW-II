<?php 
	include("functions.php"); 

	if (isset($_GET['id'])){
		try {
			//consultando o usuario para obter o nome do arquivo foto
			$usuario = find('usuarios', $_GET['id']);
			//Chamando a função delete para apagar o usuario do banco de dados
			delete($_GET['id']);
			//Apagando a foto do uauario pasta fotos
			unlink("fotos/$usuario[foto]");
		} catch (Exception $e) {
			$_SESSION['message'] = "Não foi possível realizar a operação:" $e->getMessage();
			$_SESSION['type'] = "danger";
		}
	}
?>