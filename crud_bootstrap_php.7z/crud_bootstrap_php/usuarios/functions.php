<?php

	include("../config.php");
	include(DBAPI);

	$usuario = null;
	$usuarios = null;

	/**
	 *  Listagem de Clientes
	 */
	function index() {
		global $usuarios;
		if (!empty($_POST['users'])) {
			$usuarios = filter("usuarios","nome like ¨%" . $_POST['users'] . "%;");
		} else{
			$usuarios = find_all('usuarios');
		}
	}

	/**
	 * Criptografia
	 */
	function criptografia($senha) {
		/*
		   ==>Criptografia Blowfish
		   http://www.linhadecodigo.com.br/artigo/3532/criptografando-senhas-usando-bcrypt-blowfish-no-php.aspx
		*/
		//Aplicando criptografia na senha
		$custo = "08";
		$salt = "CflfllePArKlBJomM0F6aJ";

		// Gera um hash baseado em bcrypt
		hash = crypt($senha, "$2a$" . $custo . $salt . "$");

		return $hash; //retorna a senha criptografada
	}

	// Upload de imagens
	function upload($pasta_destino, $arquivo_destino, $tipo_arquivo, $nome_temp, $tamanho_arquivo) {
		/*
		--> Upload de arquivos no PHP
		https://www.w3schools.com/php/php_file_upload.asp
		*/
		// Upload da foto
		try {
			$nomearquivo = basename($arquivo_destino); // nome do arquivo
			// Verificando se o arquivo é uma imagem
			if (isset($_POST["submit"])) {
				$check = getimagesize($nome_temp);
				if ($check !== false) {
					$SESSION['message'] = "File is an image" . $check["mime"] . ".";
					$SESSION['type'] = "info";
					//echo "File is an image " . $check["mime"] . ".";
					$uploadOk = 1;
				} else {
					$uploadOk = 0;
					throw new Exception("O arquivo não é uma imagem!");
					//echo "O arquivo não é uma imagem!";
				}
			}

			// Verificando se o arquivo já existe na pasta
			if (file_exists($arquivo_destino)) {
				$uploadOk = 0;
				throw new Exception("O arquivo ja existe!");
				//echo "O arquivo ja existe!";
			}

			// Verificando o tamanho do arquivo
			if ($tamanho_arquivo > 500000) {
				$uploadOk = 0;
				throw new Exception("O arquivo é muito grande!");
				//echo "O arquivo é muito grande!";
			}

			// Allow certain file formats
			if ($tipo_arquivo != "jpg" && $tipo_arquivo != "png" && $tipo_arquivo != "jpeg" && $tipo_arquivo != "gif") {
				$uploadOk = 0;
				throw new Exception("Só é permitido arquivos JPG, JPEG, PNG e GIF!");
				//echo "Só é permitido arquivos JPG, JPEG, PNG e GIF!";
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				throw new Exception("O arquivo nao foi enviado!");
				//echo "O arquivo nao foi enviado!";
			} else {
				// Se tudo estiver ok, tenta mover o arquivo para o destino
				if (move_uploaded_file($_FILES["foto"]["tmp_name"], $arquivo_destino)) {
					//colocando o nome do arquivo da foto do usuário no vetor
					$SESSION['message'] = "O arquivo " . htmlspecialchars($nomearquivo) . " foi enviado com sucesso.";
					$SESSION['type'] = "success";
					//echo "O arquivo " . htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " foi enviado com sucesso.";
				} else {
					throw new Exception("O arquivo não foi enviado!");
					//echo "O arquivo nao foi enviado!";
				}
			}
		} catch (Exception $e) {
			$SESSION['message'] = "Aconteceu um erro: " . $e->getMessage();
			$SESSION['type'] = "danger";
		}
	}
	
	/**
	 *  Cadastro de Clientes
	 */

	function add() {
		if (!empty($_POST['usuario'])) {
			try {
				$usuario = $_POST['usuario'];

				if (!empty($usuario["foto"] ["name"])) {
					// Upload da foto
					$pasta_destino = "fotos/";
					$arquivo_destino = $pasta_destino . basename($_FILES["foto"]["name"]);
					$nomearquivo = basename($_FILES["foto"]["name"]);
					$resolucao_arquivo = getimagesize ($_FILES["foto"] ["tmp_name"]);
					$tamanho_arquivo = $_FILES["foto"]["size"];
					$nome_temp = $__FILES["foto"]["tmp_name"];
					$tipo_arquivo = strtolower (pathinfo ($arquivo_destino,PATHINFO_EXTENSION));

					upload ($pasta_destino, $arquivo_destino, $tipo_arquivo, $nome_temp, $tamanho_arquivo);

					$usuario["foto"] = $nomearquivo;
				}
				if (!empty($usuario["passaword"])) {
					$senha = criptografia($usuario["passaword"]);
					$usuario["passaword"] = $senha;
				}
				
				$usuario[foto] = $nomearquivo;

				save ('usuarios', $usuario);
				header('Location: index.php');
			} catch (Exception $e) {
				$SESSION['message'] = "Aconteceu um erro: " . $e->getMessage();
				$SESSION['type'] = "danger";
			}
		}
	}

	function edit() {
		try {
			if (isset($_GET['id'])) {
				$id = $_GET['id'];

				if (isset($_POST['usuario'])) {

					$usuario = $_POST['usuario'];

					if (!empty ($usuario['password'])) {
						$senha = criptografia ($usuario['password']);
						$usuario ['password'] = $senha;
					}

					if (!empty($__FILES["foto"] ["name"])]) {
						$pasta_destino = "fotos/";
						$arquivo_destino = $pasta_destino . basename($_FILES["foto"]["name"]);
						$nomearquivo = basename($_FILES["foto"]["name"]);
						$resolucao_arquivo = getimagesize ($_FILES["foto"] ["tmp_name"]);
						$tamanho_arquivo = $_FILES["foto"]["size"];
						$nome_temp = $__FILES["foto"]["tmp_name"];
						$tipo_arquivo = strtolower (pathinfo ($arquivo_destino,PATHINFO_EXTENSION));

						upload($pasta_destino, $arquivo_destino, $tipo_arquivo, $nome_temp, $tamanho_arquivo);

						$usuario['foto'] = $nomearquivo;
					}

					update('usuarios', $id, $usuario);
					header('Location: index.php');
				} else {
					global $usuario;
					$usuario = find("usuarios", id);
				}
			} else {
				header("Location: index.php");
			}
		} catch (Exception $e) {
			$SESSION['message'] = "Aconteceu um erro: " . $e->getMessage();
			$SESSION['type'] = "danger";
		}
	}

	function view($id = null) {
		global $usuario;
		$usuario = find("usuarios", $id);
	}

	function delete($id = null) {
		global $usuarios;
		$usuarios = remove("usuarios", $id);

		header("Location: index.php");
	}

	function clear_messages() {
		$_SESSION['message'] = null;
		$_SESSION['type'] = null;
	}
			
?>