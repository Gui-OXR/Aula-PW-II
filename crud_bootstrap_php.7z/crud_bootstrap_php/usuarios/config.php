<?php

	include("../config.php");
	include(DBAPI);

	$usuarios = null;
	$usuario = null;

	/**
	 *  Listagem de Clientes
	 */
	function index() {
		global $usuarios;
		$usuarios = find_all('usuarios');
	}
	
	