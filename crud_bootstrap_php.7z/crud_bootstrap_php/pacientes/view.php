<?php 
	include('functions.php'); 
	view($_GET['id']);
	include(HEADER_TEMPLATE);
?>

<h2 class="mt-2">Paciente <?php echo $paciente['id']; ?></h2>
<hr>

<?php if (!empty($_SESSION['message'])) : ?>
	<div class="alert alert-<?php echo $_SESSION['type']; ?>">
		<?php echo $_SESSION['message'] . "\n"; ?>
	</div>
<?php endif; ?>

<dl class="dl-horizontal">
	<dt>Nome:</dt>
	<dd><?php echo $paciente['nome']; ?></dd>

	<dt>Quadro:</dt>
	<dd><?php echo $paciente['quadro']; ?></dd>

	<dt>Grau de Urgência:</dt>
	<dd><?php echo $paciente['urgencia']; ?></dd>

	<dt>CPF:</dt>
	<dd><?php echo $paciente['cpf']; ?></dd>

	<dt>CEP:</dt>
	<dd><?php echo $paciente['cep']; ?></dd>

	<dt>Sexo:</dt>
	<dd><?php echo $paciente['sexo']; ?></dd>

	<dt>Celular:</dt>
	<dd><?php echo telefone($paciente['celular']); ?></dd>

	<dt>Data de nascimento:</dt>
	<dd><?php echo formatadata($paciente['aniversario'], "d/m/Y"); ?></dd>
	
	<dt>Última Modificação:</dt>
	<dd><?php echo !empty($paciente['modificado']) ? formatadata($paciente['modificado'], "d/m/Y H:i:s") : 'Não alterado'; ?></dd>
</dl>

<dl class="dl-horizontal">
	<dt>Imagem:</dt>
	<dd>
		<?php if (!empty($paciente['imagem'])): ?>
			<img src="../imagens/<?php echo $paciente['imagem']; ?>" alt="Imagem do paciente" style="max-width: 200px;">
		<?php else: ?>
			<p>Sem imagem disponível</p>
		<?php endif; ?>
	</dd>
</dl>

<div id="actions" class="row">
	<div class="col-md-12">
	  <a href="edit.php?id=<?php echo $paciente['id']; ?>" class="btn btn-secondary">
	    <i class="fa-solid fa-pen-to-square"></i> Editar
	  </a>
	  <a href="index.php" class="btn btn-light">
	    <i class="fa-solid fa-arrow-rotate-left"></i> Voltar
	  </a>
	</div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
