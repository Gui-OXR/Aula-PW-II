<?php 
	include("functions.php"); 
	add();
	include(HEADER_TEMPLATE); 
?>

<h2 class="mt-2">Novo Paciente</h2>

<form action="add.php" method="post" enctype="multipart/form-data">
  <!-- área de campos do form -->
  <hr />
  <div class="row">
    <div class="form-group col-md-7">
      <label for="nome">Nome</label>
      <input type="text" class="form-control" name="nome" required>
    </div>

    <div class="form-group col-md-5">
      <label for="quadro">Quadro</label>
      <input type="text" class="form-control" name="quadro" required>
    </div>
  </div>

  <div class="row">
    <div class="form-group col-md-2">
      <label for="urgencia">Grau de Urgência</label>
      <input type="number" class="form-control" name="urgencia" required>
    </div>

    <div class="form-group col-md-3">
      <label for="cpf">CPF</label>
      <input type="tel" class="form-control" name="cpf" maxlength="11" required>
    </div>

    <div class="row">
    <div class="form-group col-md-3">
      <label for="cep">CEP</label>
      <input type="tel" class="form-control" name="cep" maxlength="8" required>
    </div>

    <div class="form-group col-md-2">
      <label for="sexo">Sexo</label>
      <input type="text" class="form-control" name="sexo" maxlength="1" required>
    </div>

    <div class="form-group col-md-2">
      <label for="celular">Celular</label>
      <input type="tel" class="form-control" name="celular" maxlength="11" required>
    </div>
  </div>

  <div class="row">
    <div class="form-group col-md-3">
      <label for="aniversario">Data de nascimento</label>
      <input type="date" class="form-control" name="aniversario" required>
    </div>
    <div class="form-group col-md-6">
      <label for="imagem">Imagem</label>
      <input type="file" class="form-control" name="imagem" required>
    </div>
  </div>

  <div id="actions" class="row">
    <div class="col-md-12 mt-2">
      <button type="submit" class="btn btn-secondary"> <i class="fa-solid fa-sd-card"></i> Salvar</button>
      <a href="index.php" class="btn btn-light"> <i class="fa-solid fa-ban"></i> Cancelar</a>
    </div>
  </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
