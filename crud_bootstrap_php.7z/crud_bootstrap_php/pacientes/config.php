<?php

	include("../config.php");
	include(DBAPI);

	$pacientes = null;
	$paciente = null;

	/**
	 *  Listagem de Produtos
	 */
	function index() {
		global $pacientes;
		$pacientes = find_all('tabeladados');
	}