<!-- Modal -->
<div class="modal fade" id="delete-modal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Excluir Paciente</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Você tem certeza que deseja excluir este Paciente?</p>
      </div>
      <div class="modal-footer">
        <a href="delete.php?id=<?php echo $paciente['id']; ?>" class="btn btn-dark" id="confirm"><i class="fa-regular fa-circle-check"></i> Sim</a>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fa-regular fa-circle-xmark"></i> Não</button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteModal = document.getElementById('delete-modal');
    deleteModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget; // Botão que acionou o modal
        var id = button.getAttribute('data-paciente'); // Extrai o ID do botão
        var confirmButton = deleteModal.querySelector('#confirm'); // Botão de confirmação no modal
        
        // Define o link de confirmação para excluir o produto
        confirmButton.setAttribute('href', 'delete.php?id=' + id);
    });
});
</script>
