<?php 
	include("functions.php"); 
	edit();
	include(HEADER_TEMPLATE); 
?>

<h2 class="mt-2">Atualizar Paciente</h2>

<form action="edit.php?id=<?php echo $paciente['id']; ?>" method="post" enctype="multipart/form-data">
  <!-- área de campos do form -->
  <hr />
  <div class="row">
    <div class="form-group col-md-7">
      <label for="nome">Nome</label>
      <input type="text" class="form-control" name="paciente['nome']" value="<?php echo $paciente['nome']; ?>" required>
    </div>

    <div class="form-group col-md-5">
      <label for="quadro">Quadro</label>
      <input type="text" class="form-control" name="paciente['quadro']" value="<?php echo $paciente['quadro']; ?>" required>
    </div>
  </div>

  <div class="row">
    <div class="form-group col-md-2">
      <label for="urgencia">Grau de Urgência</label>
      <input type="number" class="form-control" name="paciente['urgencia']" value="<?php echo $paciente['urgencia']; ?>" required>
    </div>

    <div class="form-group col-md-3">
      <label for="cpf">CPF</label>
      <input type="tel" class="form-control" name="paciente['cpf']" value="<?php echo $paciente['cpf']; ?>" maxlength="11" required>
    </div>

    <div class="form-group col-md-3">
      <label for="cep">CEP</label>
      <input type="tel" class="form-control" name="paciente['cep']" value="<?php echo $paciente['cep']; ?>" maxlength="8" required>
    </div>

    <div class="form-group col-md-2">
      <label for="sexo">Sexo</label>
      <input type="text" class="form-control" name="paciente['sexo']" value="<?php echo $paciente['sexo']; ?>" maxlength="1" required>
    </div>

    <div class="form-group col-md-2">
      <label for="celular">Celular</label>
      <input type="tel" class="form-control" name="paciente['celular']" value="<?php echo $paciente['celular']; ?>" maxlength="11" required>
    </div>
  </div>

  <div class="row">
    <div class="form-group col-md-3">
      <label for="aniversario">Data de nascimento</label>
      <input type="date" class="form-control" name="paciente['aniversario']" value="<?php echo $paciente['aniversario']; ?>" required>
    </div>

    <div class="form-group col-md-6">
      <label for="imagem">Imagem</label>
      <input type="file" class="form-control" name="paciente['imagem']">
      <p>Arquivo atual: <?php echo $paciente['imagem']; ?></p>
    </div>
  </div>

  <div class="row">
    <div class="form-group col-md-3">
      <label for="modificado">Última Modificação</label>
      <input type="text" class="form-control" name="paciente['modificado']" value="<?php echo $paciente['modificado']; ?>" disabled>
    </div>
  </div>

  <div id="actions" class="row">
    <div class="col-md-12 mt-2">
      <button type="submit" class="btn btn-secondary"> <i class="fa-solid fa-sd-card"></i> Salvar</button>
      <a href="index.php" class="btn btn-light"> <i class="fa-solid fa-ban"></i> Cancelar</a>
    </div>
  </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
